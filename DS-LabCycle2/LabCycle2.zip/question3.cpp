#include <iostream>
#include <string>
#include <vector>

// Selection Sort function to sort an array of strings lexicographically
void selectionSort(std::vector<std::string>& arr) {
    int n = arr.size();
    
    for (int i = 0; i < n - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {
            std::swap(arr[i], arr[minIndex]);
        }
    }
}

int main() {
    int n;
    std::cout<<"Enter the number of strings: ";
    std::cin >> n;

    std::vector<std::string> strings(n);
    std::cout<<"Enter the strings:" <<std::endl;
    for (int i = 0; i < n; ++i)
    {
        std::cin >> strings[i];
    }

    selectionSort(strings);

    for (const std::string& str : strings) {
        std::cout << str << " ";
    }

    return 0;
}
