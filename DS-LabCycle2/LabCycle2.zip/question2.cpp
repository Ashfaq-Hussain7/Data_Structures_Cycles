/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

void insertionSortDescending(unsigned int arr[], int size) {
    for (int i = 1; i < size; ++i) {
        unsigned int key = arr[i];
        int j = i - 1;
        
        // Move elements of arr[0..i-1], that are greater than key, to one position ahead of their current position
        while (j >= 0 && arr[j] < key) {
            arr[j + 1] = arr[j];
            --j;
        }
        arr[j + 1] = key;
    }
}

int main() {
    unsigned int unsorted_array[] = {9, 5, 7, 1, 3};
    int size = sizeof(unsorted_array) / sizeof(unsorted_array[0]);

    std::cout << "Unsorted array:";
    for (int i = 0; i < size; ++i) {
        std::cout << " " << unsorted_array[i];
    }
    std::cout << std::endl;

    insertionSortDescending(unsorted_array, size);

    std::cout << "Sorted array:";
    for (int i = 0; i < size; ++i) {
        std::cout << " " << unsorted_array[i];
    }
    std::cout << std::endl;

    return 0;
}


